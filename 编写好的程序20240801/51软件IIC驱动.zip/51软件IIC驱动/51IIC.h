#ifndef __51IIC_H
#define __51IIC_H

#include "REG51.h"		  	 
 
#define  u8 unsigned char 
#define  u16 unsigned int
#define  u32 unsigned int
	



void I2C_Init(void);
void I2C_Start(void);
void I2C_Stop(void);
void I2C_Send_Byte(unsigned char byte);
unsigned char I2C_Wait_Ack(void);
void I2C_NoAck(void);
unsigned char I2C_Read_Byte(void);
unsigned char I2C_Write(unsigned char WriteAddr, unsigned char* pBuf, unsigned int Len);
unsigned char I2C_Read(unsigned char ReadAddr, unsigned char* pCmd, unsigned int Len, unsigned char *rx_buf);

#endif



