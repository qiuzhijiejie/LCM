
#include "51IIC.h"	 

#include <reg51.h>  // Include the 8051 register definitions

// Define the I2C pins for STC89C51
sbit SCL = P3^1; // P3.1 as SCL
sbit SDA = P3^0; // P3.0 as SDA

#define SDA_H   SDA = 1  // Set SDA high
#define SDA_L   SDA = 0  // Set SDA low
#define SCL_H   SCL = 1  // Set SCL high
#define SCL_L   SCL = 0  // Set SCL low






static void I2C_delay(void) {
    volatile unsigned char i = 25;    
    while (i--);  
}


void I2C_Start(void) {
    SDA_H;          
    SCL_H;          
    I2C_delay(); 
    SDA_L;          
    I2C_delay(); 
    SCL_L;          
    I2C_delay();  
}

// I2C????
void I2C_Stop(void) {
    SCL_L;          
    SDA_L;          
    I2C_delay();
    SCL_H;          
    I2C_delay();
    SDA_H;          
    I2C_delay();
}


static unsigned char I2C_Wait_Ack(void) {
    unsigned char tempTime = 0;
    SDA_H;          
    I2C_delay();
    SCL_H;          
    I2C_delay();
    while (SDA) {   
        tempTime++;
        if (tempTime > 250) {
            I2C_Stop();
            return 1; 
        }
    }
    SCL_L;          
    I2C_delay();
    return 0;      
}


void I2C_Send_Byte(unsigned char byte) {
    unsigned char t;
    SCL_L;         
    for (t = 0; t < 8; t++) {
        if (byte & 0x80) {
            SDA_H;  
        } else {
            SDA_L;  
        }
        byte <<= 1; 
        I2C_delay();
        SCL_H;      
        I2C_delay();
        SCL_L;      
        I2C_delay();
    }
}

unsigned char I2C_Write(unsigned char WriteAddr, unsigned char* pBuf, unsigned int Len) {
    unsigned int i;
    I2C_Start();  

    I2C_Send_Byte(WriteAddr); 
    if (I2C_Wait_Ack() == 1) { 
        return 0; 
    }

    for (i = 0; i < Len; i++) {
        I2C_Send_Byte(pBuf[i]);
        if (I2C_Wait_Ack() == 1) {
            return 0; 
        }
    }

    I2C_Stop();  
    return 1; 
}


